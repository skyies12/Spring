package com.study.spring20.frontcontroller;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.study.spring20.NicknamedeleteOk;
import com.study.spring20.NiknameOk;
import com.study.spring20.Service;
import com.study.spring20.deleteOk;
import com.study.spring20.idcheckOk;
import com.study.spring20.joinOk;
import com.study.spring20.loginOk;
import com.study.spring20.modifyOk;
import com.study.spring20.ratingmodifyOk;
import com.study.spring20.command.BCommand;
import com.study.spring20.command.BContentCommand;
import com.study.spring20.command.BDeleteCommand;
import com.study.spring20.command.BListCommand;
import com.study.spring20.command.BModifyCommand;
import com.study.spring20.command.BReplyCommand;
import com.study.spring20.command.BReplyViewCommand;
import com.study.spring20.command.BSelectCommand;
import com.study.spring20.command.BWriteCommand;
import com.study.spring20.command.FileModifyCommand;
import com.study.spring20.command.FileUploadCommand;
import com.study.spring20.command.MemberListCommand;

@Controller
public class BController {

	String viewPage = null;
	BCommand command = null;
	Service service = null;
	
	@RequestMapping("/login")
	public String login(HttpServletRequest request,HttpServletResponse response, Model model) {
		return "login";
	}
	
	@RequestMapping(value = "/loginOk", method = RequestMethod.POST)
	public void loginOk(HttpServletRequest request,HttpServletResponse response, Model model) {
		service = new loginOk();
		service.execute(request, response, model);
	}
	
	@RequestMapping(value = "/idcheckOk", method = RequestMethod.POST)
	public String idcheckOk(HttpServletRequest request,HttpServletResponse response, Model model) {
		service = new idcheckOk();
		service.execute(request, response, model);
		return "join";
	}
	
	@RequestMapping("/main")
	public String main(HttpServletRequest request,HttpServletResponse response, Model model) {
		
		return "main-login";
	}
	
	@RequestMapping("/join")
	public String join(HttpServletRequest request,HttpServletResponse response, Model model) {
		return "join";
	}
//	else if(com.equals("/loginOk.do")) {
//		Service service = new loginOk();
//		service.execute(request, response);
//	} 
}

//	if(com.equals("/write_view.do")) {
//		viewPage = "write_view.jsp";
//	} else if(com.equals("/write.do")) {
//		command = new BWriteCommand();
//		command.execute(request, response);
//		viewPage = "list.do";
//	} else if(com.equals("/list.do")) {
//		command = new BListCommand();
//		command.execute(request, response);
//		viewPage = "list.jsp";
//	} else if(com.equals("/filesUpload.do")) {
//		command = new FileUploadCommand();
//		command.execute(request, response);
//		viewPage = "list.do";
//	} else if(com.equals("/upload_view.do")) {
//		viewPage = "upload_view.jsp";
//	}else if(com.equals("/content_view.do")) {
//		command = new BContentCommand();
//		command.execute(request, response);
//		viewPage = "content_view.jsp";
//	}else if(com.equals("/filecontent_view.do")) {
//		command = new BContentCommand();
//		command.execute(request, response);
//		viewPage = "file_view.jsp";
//	} else if(com.equals("/filemodify_view.do")) {
//		command = new BContentCommand();
//		command.execute(request, response);
//		viewPage = "filemodify_view.jsp";
//	} else if(com.equals("/filemodify.do")) {
//		command = new FileModifyCommand();
//		command.execute(request, response);
//
//		command = new BContentCommand();
//		command.execute(request, response);
//		viewPage = "list.do";
//	} else if(com.equals("/modify_view.do")) {
//		command = new BContentCommand();
//		command.execute(request, response);
//		viewPage = "modify_view.jsp";
//	} else if(com.equals("/modify.do")) {
//		command = new BModifyCommand();
//		command.execute(request, response);
//
//		command = new BContentCommand();
//		command.execute(request, response);
//		viewPage = "list.do";
//	} else if(com.equals("/delete.do")) {
//		command = new BDeleteCommand();
//		command.execute(request, response);
//		viewPage = "list.do?page="+curPage;
//	} else if(com.equals("/reply_view.do")) {
//		command = new BReplyViewCommand();
//		command.execute(request, response);
//		viewPage = "reply_view.jsp";
//	} else if(com.equals("/reply.do")) {
//		command = new BReplyCommand();
//		command.execute(request, response);
//		viewPage = "list.do?page="+curPage;
//	} else if(com.equals("/select.do")) {
//		command = new BSelectCommand();
//		command.execute(request, response);
//		viewPage = "select.jsp";
//	} else if(com.equals("/loginOk.do")) {
//		Service service = new loginOk();
//		service.execute(request, response);
//	} else if(com.equals("/modifyOk.do")) {
//		Service service = new modifyOk();
//		service.execute(request, response);
//	} else if(com.equals("/ratingmodifyOk.do")) {
//		Service service = new ratingmodifyOk();
//		service.execute(request, response);
//	} else if(com.equals("/joinOk.do")) {
//		Service service = new joinOk();
//		service.execute(request, response);
//	} else if(com.equals("/idcheckOk.do")) {
//		Service service = new idcheckOk();
//		service.execute(request, response);
//	} else if(com.equals("/deletekOk.do")) {
//		Service service = new deleteOk();
//		service.execute(request, response);
//	} else if(com.equals("/logout.do")) {
//		session.invalidate();
//		viewPage = "login.jsp";
//	} else if(com.equals("/nickname.do")) {
//		Service service = new NiknameOk();
//		service.execute(request, response);
//	} else if(com.equals("/nicknamedeleteOk.do")) {
//		Service service = new NicknamedeleteOk();
//		service.execute(request, response);
//	} else if(com.equals("/member.do")) {
//		command = new MemberListCommand();
//		command.execute(request, response);
//		viewPage = "memberlist.jsp";
//	}

